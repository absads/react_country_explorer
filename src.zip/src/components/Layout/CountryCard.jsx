import { NavLink } from 'react-router-dom'
import '../../styles/CountryCard.css'

function CountryCard({ country }) {
  return (
    <li className="country-card">
      <div className="card-image">
        <img src={country.flag} alt={`${country.name} flag`} className="flag-image" />
      </div>

      <div className="card-info">
        <h2 className="card-title">{country.name}</h2>

        <div className="card-details">
          <p>
            <span className="card-label">Population:</span> {country.population ? country.population.toLocaleString() : 'N/A'}
          </p>
          <p>
            <span className="card-label">Region:</span> {country.region}
          </p>
          <p>
            <span className="card-label">Capital:</span> {country.capital || 'N/A'}
          </p>
        </div>

        <NavLink to={`/country/${country.alpha3Code}`}>
          <button className="card-button">Read More</button>
        </NavLink>
      </div>
    </li>
  )
}

export default CountryCard
