import { useEffect, useState, useTransition } from 'react'
import { NavLink, useParams } from 'react-router-dom'
import { getCountryByCode } from '../../services/countryService'
import Loader from '../UI/Loader'
import '../../styles/CountryDetails.css'

function CountryDetails() {
  const params = useParams()
  const [isPending, startTransition] = useTransition()
  const [country, setCountry] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => {
    startTransition(async () => {
      try {
        const res = await getCountryByCode(params.id)
        setCountry(res)
        setError(null)
      } catch (err) {
        console.error('Error loading country:', err)
        setError('Country not found')
      }
    })
  }, [params.id])

  if (isPending) return <Loader />

  if (error) {
    return (
      <section className="card country-details-card container">
        <div className="container-card bg-white-box">
          <p className="error-message">{error}</p>
          <div className="country-card-backBtn">
            <NavLink to="/country" className="backBtn">
              <button>Go Back</button>
            </NavLink>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="card country-details-card container">
      <div className="container-card bg-white-box">
        {country && (
          <div className="country-image grid grid-two-cols">
            <img src={country.flag} alt={`${country.name} flag`} className="flag" />
            <div className="country-content">
              <p className="card-title">{country.name}</p>

              <div className="infoContainer">
                {country.nativeName && (
                  <p>
                    <span className="card-description">Native Names:</span>
                    {country.nativeName}
                  </p>
                )}

                <p>
                  <span className="card-description">Population:</span>
                  {country.population ? country.population.toLocaleString() : 'N/A'}
                </p>

                <p>
                  <span className="card-description">Region:</span>
                  {country.region}
                </p>

                <p>
                  <span className="card-description">Sub Region:</span>
                  {country.subregion || 'N/A'}
                </p>

                <p>
                  <span className="card-description">Capital:</span>
                  {country.capital || 'N/A'}
                </p>

                <p>
                  <span className="card-description">Area:</span>
                  {country.area ? country.area.toLocaleString() : 'N/A'} km²
                </p>

                <p>
                  <span className="card-description">Top Level Domain:</span>
                  {country.topLevelDomain ? country.topLevelDomain.join(', ') : 'N/A'}
                </p>

                {country.currencies && country.currencies.length > 0 && (
                  <p>
                    <span className="card-description">Currencies:</span>
                    {country.currencies.map((c) => c.name).join(', ')}
                  </p>
                )}

                {country.languages && country.languages.length > 0 && (
                  <p>
                    <span className="card-description">Languages:</span>
                    {country.languages.map((l) => l.name).join(', ')}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="country-card-backBtn">
          <NavLink to="/country" className="backBtn">
            <button>Go Back</button>
          </NavLink>
        </div>
      </div>
    </section>
  )
}

export default CountryDetails
