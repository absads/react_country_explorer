import { getUniqueRegions } from '../../services/countryService'
import '../../styles/SearchFilter.css'

function SearchFilter({ search, setSearch, filter, setFilter, countries }) {
  const regions = getUniqueRegions(countries)

  return (
    <section className="search-filter-section">
      <div className="container">
        <input
          type="text"
          placeholder="Search countries..."
          value={search || ''}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input"
        />

        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="filter-select"
        >
          <option value="all">All Regions</option>
          {regions.map((region) => (
            <option key={region} value={region}>
              {region}
            </option>
          ))}
        </select>
      </div>
    </section>
  )
}

export default SearchFilter
