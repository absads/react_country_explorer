import { NavLink } from 'react-router-dom'
import '../../styles/Footer.css'

function Footers() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-content">
          <div className="footer-section">
            <div className="footer-logo">
              <span className="footer-logo-icon">🌍</span>
              <h3>Country Explorer</h3>
            </div>
            <p className="footer-description">
              Discover the world's countries with comprehensive data and fascinating information about nations and cultures.
            </p>
            <div className="social-links">
              <a href="#" className="social-icon" title="Facebook">
                f
              </a>
              <a href="#" className="social-icon" title="Twitter">
                𝕏
              </a>
              <a href="#" className="social-icon" title="Instagram">
                📷
              </a>
            </div>
          </div>

          <div className="footer-section">
            <h4>Quick Links</h4>
            <ul className="footer-links">
              <li>
                <NavLink to="/">Home</NavLink>
              </li>
              <li>
                <NavLink to="/country">Countries</NavLink>
              </li>
              <li>
                <NavLink to="/about">About</NavLink>
              </li>
              <li>
                <NavLink to="/contact">Contact</NavLink>
              </li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Information</h4>
            <ul className="footer-links">
              <li>
                <a href="/">Privacy Policy</a>
              </li>
              <li>
                <a href="/">Terms & Conditions</a>
              </li>
              <li>
                <a href="/">Support</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; {currentYear} Country Explorer. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footers
