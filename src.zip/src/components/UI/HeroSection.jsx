import { NavLink } from 'react-router-dom'
import '../../styles/HeroSection.css'

function HeroSection() {
  return (
    <section className="hero-section">
      <div className="container">
        <div className="hero-content">
          <h1 className="hero-title">Explore the World</h1>
          <p className="hero-subtitle">Discover fascinating facts about countries, cultures, and people across the globe</p>
          <NavLink to="/country">
            <button className="hero-button">Explore Countries</button>
          </NavLink>
        </div>
      </div>
    </section>
  )
}

export default HeroSection
