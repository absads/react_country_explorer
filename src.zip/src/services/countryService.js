import countriesData from '../api/countries.json'

/**
 * Get all countries from local JSON data
 */
export const getAllCountries = () => {
  return countriesData
}

/**
 * Get a single country by alpha3Code (e.g., "USA", "GBR")
 */
export const getCountryByCode = (code) => {
  if (!code) return null
  
  const country = countriesData.find(
    (c) => c.alpha3Code === code.toUpperCase()
  )
  
  if (!country) {
    throw new Error(`Country with code ${code} not found`)
  }
  
  return country
}

/**
 * Filter countries by search query (name or capital)
 */
export const filterCountries = (countries, searchQuery, selectedRegion) => {
  let filtered = countries

  // Filter by search query (name or capital)
  if (searchQuery.trim()) {
    const query = searchQuery.toLowerCase()
    filtered = filtered.filter((country) => {
      const nameMatch = country.name.toLowerCase().includes(query)
      const capitalMatch = country.capital && country.capital.toLowerCase().includes(query)
      return nameMatch || capitalMatch
    })
  }

  // Filter by region
  if (selectedRegion && selectedRegion !== 'All') {
    filtered = filtered.filter((country) => country.region === selectedRegion)
  }

  return filtered
}

/**
 * Get unique regions from countries data
 */
export const getUniqueRegions = (countries) => {
  const regions = new Set(countries.map((c) => c.region))
  return Array.from(regions).sort()
}

/**
 * Search countries by name
 */
export const searchCountries = (searchQuery) => {
  const query = searchQuery.toLowerCase()
  return countriesData.filter((country) => {
    const nameMatch = country.name.toLowerCase().includes(query)
    const capitalMatch = country.capital && country.capital.toLowerCase().includes(query)
    return nameMatch || capitalMatch
  })
}
