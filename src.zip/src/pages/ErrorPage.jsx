import { useNavigate } from 'react-router-dom'

function ErrorPage() {
  const navigate = useNavigate()

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        color: 'white',
        textAlign: 'center',
        padding: '20px'
      }}
    >
      <div style={{ fontSize: '5rem', marginBottom: '20px' }}>404</div>
      <h1 style={{ fontSize: '2.5rem', margin: '0 0 10px 0' }}>Page Not Found</h1>
      <p style={{ fontSize: '1.1rem', margin: '0 0 30px 0', opacity: 0.9 }}>
        Sorry, the page you're looking for doesn't exist.
      </p>
      <button
        onClick={() => navigate('/')}
        style={{
          padding: '12px 30px',
          background: 'white',
          color: '#667eea',
          border: 'none',
          borderRadius: '6px',
          fontSize: '1rem',
          fontWeight: '600',
          cursor: 'pointer',
          transition: 'all 0.3s ease',
          boxShadow: '0 5px 15px rgba(0, 0, 0, 0.2)'
        }}
        onMouseEnter={(e) => {
          e.target.style.transform = 'translateY(-3px)'
          e.target.style.boxShadow = '0 8px 25px rgba(0, 0, 0, 0.3)'
        }}
        onMouseLeave={(e) => {
          e.target.style.transform = 'translateY(0)'
          e.target.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.2)'
        }}
      >
        ← Back to Home
      </button>
    </div>
  )
}

export default ErrorPage
