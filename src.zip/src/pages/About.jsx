import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import '../styles/About.css'

function About() {
  const navigate = useNavigate()
  const [expandedFeature, setExpandedFeature] = useState(null)

  const features = [
    {
      id: 1,
      icon: '🌍',
      title: 'Explore All Countries',
      description: 'Browse information about 250+ countries and territories from around the world with comprehensive data.'
    },
    {
      id: 2,
      icon: '🚩',
      title: 'Flag Images',
      description: 'View beautiful, high-quality flag images for every country in the world in SVG format.'
    },
    {
      id: 3,
      icon: '🏛️',
      title: 'Capital Information',
      description: 'Discover capital cities and their geographical coordinates for each country.'
    },
    {
      id: 4,
      icon: '👥',
      title: 'Population Data',
      description: 'Access current and accurate population statistics for demographic insights and comparisons.'
    },
    {
      id: 5,
      icon: '🗣️',
      title: 'Language Details',
      description: 'Learn about the languages spoken in each country and expand your cultural knowledge.'
    },
    {
      id: 6,
      icon: '💱',
      title: 'Currency & Economy',
      description: 'Explore currency information, symbols, and economic details for each nation.'
    },
    {
      id: 7,
      icon: '🌐',
      title: 'Real-Time API Data',
      description: 'Get up-to-date information powered by the REST Countries API, always accurate and current.'
    },
    {
      id: 8,
      icon: '📱',
      title: 'Mobile Friendly',
      description: 'Fully responsive design that works perfectly on desktop, tablet, and mobile devices.'
    }
  ]

  const toggleFeature = (id) => {
    setExpandedFeature(expandedFeature === id ? null : id)
  }

  return (
    <div className="about-container">
      <div className="about-wrapper">
        {/* Hero Section */}
        <section className="about-hero">
          <div className="hero-content">
            <h1>About Country Explorer</h1>
            <p className="hero-subtitle">
              Your comprehensive guide to exploring the world's countries
            </p>
            <p className="hero-description">
              Country Explorer is a modern, interactive web application designed to help you discover and learn about countries from every corner of the globe. 
              With real-time data and an intuitive interface, explore fascinating information about nations, cultures, and geographical details.
            </p>
          </div>
        </section>

        {/* Mission Section */}
        <section className="mission-section">
          <div className="mission-card">
            <h2>🎯 Our Mission</h2>
            <p>
              We believe that knowledge of our world brings us closer together. Country Explorer is dedicated to making global information 
              accessible, engaging, and educational for everyone. Whether you're a student, traveler, researcher, or simply curious about the world, 
              we provide the tools you need to explore and understand our diverse planet.
            </p>
          </div>

          <div className="mission-card">
            <h2>✨ Why Choose Us?</h2>
            <ul className="reasons-list">
              <li>✓ Access data for 250+ countries and territories</li>
              <li>✓ Real-time, regularly updated information</li>
              <li>✓ Beautiful, intuitive user interface</li>
              <li>✓ Fast, responsive performance</li>
              <li>✓ Completely free and open to everyone</li>
              <li>✓ Works on all devices and browsers</li>
            </ul>
          </div>
        </section>

        {/* Features Section */}
        <section className="features-section">
          <div className="section-header">
            <h2>✨ Amazing Features</h2>
            <p>Discover what makes Country Explorer special</p>
          </div>

          <div className="features-grid">
            {features.map((feature) => (
              <div
                key={feature.id}
                className={`feature-card ${expandedFeature === feature.id ? 'expanded' : ''}`}
                onClick={() => toggleFeature(feature.id)}
              >
                <div className="feature-icon">{feature.icon}</div>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Stats Section */}
        <section className="stats-section">
          <div className="stat-card">
            <div className="stat-number">250+</div>
            <div className="stat-label">Countries & Territories</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">195</div>
            <div className="stat-label">UN Member States</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">7.9B</div>
            <div className="stat-label">World Population</div>
          </div>
          <div className="stat-card">
            <div className="stat-number">7000+</div>
            <div className="stat-label">Languages Spoken</div>
          </div>
        </section>

        {/* Use Cases Section */}
        <section className="use-cases-section">
          <div className="section-header">
            <h2>📚 Who Can Benefit?</h2>
            <p>Country Explorer is perfect for a wide range of users</p>
          </div>

          <div className="use-cases-grid">
            <div className="use-case-card">
              <div className="use-case-icon">👨‍🎓</div>
              <h3>Students</h3>
              <p>Perfect for geography assignments, research projects, and expanding your knowledge about the world.</p>
            </div>
            <div className="use-case-card">
              <div className="use-case-icon">✈️</div>
              <h3>Travelers</h3>
              <p>Plan your trips effectively with detailed information about your destination countries and their characteristics.</p>
            </div>
            <div className="use-case-card">
              <div className="use-case-icon">💼</div>
              <h3>Business Professionals</h3>
              <p>Conduct market research and gather business intelligence about international markets and economies.</p>
            </div>
            <div className="use-case-card">
              <div className="use-case-icon">🌍</div>
              <h3>Global Enthusiasts</h3>
              <p>Satisfy your curiosity about different cultures, languages, and geographical features around the world.</p>
            </div>
          </div>
        </section>

        {/* Technology Section */}
        <section className="tech-section">
          <div className="section-header">
            <h2>🚀 Built With Modern Technology</h2>
            <p>Powered by cutting-edge tools and frameworks</p>
          </div>

          <div className="tech-grid">
            <div className="tech-card">
              <div className="tech-icon">⚛️</div>
              <h3>React 19</h3>
              <p>Modern JavaScript library for building interactive and dynamic user interfaces with hooks and state management.</p>
            </div>
            <div className="tech-card">
              <div className="tech-icon">⚡</div>
              <h3>Vite</h3>
              <p>Next-generation build tool providing lightning-fast development server and optimized production builds.</p>
            </div>
            <div className="tech-card">
              <div className="tech-icon">🔗</div>
              <h3>React Router</h3>
              <p>Powerful routing library for seamless navigation and multiple pages within our single-page application.</p>
            </div>
            <div className="tech-card">
              <div className="tech-icon">📡</div>
              <h3>REST Countries API</h3>
              <p>Reliable, comprehensive data source providing accurate and up-to-date information about every country.</p>
            </div>
            <div className="tech-card">
              <div className="tech-icon">📦</div>
              <h3>Axios</h3>
              <p>Promise-based HTTP client for making reliable API requests and handling data fetching efficiently.</p>
            </div>
            <div className="tech-card">
              <div className="tech-icon">🎨</div>
              <h3>Modern CSS3</h3>
              <p>Beautiful, responsive design using CSS Grid, Flexbox, gradients, and animations for optimal user experience.</p>
            </div>
          </div>
        </section>

        {/* Features Highlight */}
        <section className="features-highlight">
          <div className="section-header">
            <h2>📊 Detailed Country Information</h2>
            <p>Each country profile includes</p>
          </div>

          <div className="highlight-grid">
            <div className="highlight-item">
              <span className="highlight-emoji">🚩</span>
              <span>Flag Image</span>
            </div>
            <div className="highlight-item">
              <span className="highlight-emoji">🏛️</span>
              <span>Capital City</span>
            </div>
            <div className="highlight-item">
              <span className="highlight-emoji">👥</span>
              <span>Population</span>
            </div>
            <div className="highlight-item">
              <span className="highlight-emoji">🗣️</span>
              <span>Languages</span>
            </div>
            <div className="highlight-item">
              <span className="highlight-emoji">💱</span>
              <span>Currencies</span>
            </div>
            <div className="highlight-item">
              <span className="highlight-emoji">🌍</span>
              <span>Region & Area</span>
            </div>
            <div className="highlight-item">
              <span className="highlight-emoji">⏰</span>
              <span>Time Zones</span>
            </div>
            <div className="highlight-item">
              <span className="highlight-emoji">🌐</span>
              <span>Domain & Calling Code</span>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="cta-section">
          <h2>🌟 Ready to Explore the World?</h2>
          <p>Start your journey of discovery today and learn about countries across the globe</p>
          <button className="cta-button" onClick={() => navigate('/')}>
            Explore Countries Now
          </button>
        </section>

        {/* Contact Section */}
        <section className="contact-cta-section">
          <h2>💬 Questions or Suggestions?</h2>
          <p>We'd love to hear from you! Your feedback helps us improve Country Explorer.</p>
          <button className="contact-button" onClick={() => navigate('/contact')}>
            Get In Touch
          </button>
        </section>
      </div>
    </div>
  )
}

export default About
